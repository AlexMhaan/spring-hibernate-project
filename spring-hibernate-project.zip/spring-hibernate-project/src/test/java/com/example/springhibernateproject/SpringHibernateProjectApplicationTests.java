package com.example.springhibernateproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
